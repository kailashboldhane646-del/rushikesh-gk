GK CHAMPION WEBSITE BUNDLE

FILES TO UPLOAD TO THE ROOT OF YOUR EXISTING GitHub repository:
- index.html (main site; includes the original quiz/profile/history logic plus visual refresh)
- manifest.json (PWA metadata)
- sw.js (service worker for app-shell caching)

IMPORTANT: Upload all three files to the SAME root folder. In GitHub Pages, select branch main and folder /(root). Wait a minute after Commit changes. Open the HTTPS site and use the browser menu -> Install app / Add to Home screen. PWA installation requires HTTPS and browser support.

FEATURE STATUS:
- Modern styling and animation: included
- Existing question categories and quiz bank: preserved
- Profile and quiz history: existing app features preserved
- Leaderboard: existing version is LOCAL to this browser/device; it is not a global online ranking
- Cloud sync: existing Supabase auth/profile sync code preserved. For it to work, run supabase-setup.sql in Supabase SQL Editor. This syncs profile/history data for a signed-in account, not a cross-user global leaderboard.

After uploading, test sign-up/login and cloud save on a test account. Never put a Supabase service-role key in this website.
