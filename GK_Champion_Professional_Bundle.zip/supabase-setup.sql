-- Run this in Supabase SQL Editor to enable per-user cloud profile sync.
create table if not exists public.user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Learner',
  profile_data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_profiles enable row level security;
drop policy if exists "Users can read own GK profile" on public.user_profiles;
drop policy if exists "Users can insert own GK profile" on public.user_profiles;
drop policy if exists "Users can update own GK profile" on public.user_profiles;
create policy "Users can read own GK profile" on public.user_profiles for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert own GK profile" on public.user_profiles for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own GK profile" on public.user_profiles for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
